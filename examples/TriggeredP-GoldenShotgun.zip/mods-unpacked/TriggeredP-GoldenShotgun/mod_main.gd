extends Node


const AUTHORNAME_MODNAME_DIR := "TriggeredP-GoldenShotgun"
const AUTHORNAME_MODNAME_LOG_NAME := "TriggeredP-GoldenShotgun:Main"

var mod_dir_path := ""
var extensions_dir_path := ""
var translations_dir_path := ""


func _init() -> void:
	mod_dir_path = ModLoaderMod.get_unpacked_dir().plus_file(AUTHORNAME_MODNAME_DIR)
	# Add extensions
	install_script_extensions()
	# Add translations
	add_translations()

func install_script_extensions() -> void:
	extensions_dir_path = mod_dir_path.plus_file("extensions")

func add_translations() -> void:
	translations_dir_path = mod_dir_path.plus_file("translations")

func _ready() -> void:
	add_golden_ammo()
	add_golden_shotgun()
	
	PPRUtilities.locations.add_weapon("EFP HQ", "Golden Shotgun", Vector3(1.2, 1.2, -26.6), Vector3(0.0, -49.118, 0.0))

func add_golden_ammo():
	var golden_ammo = PPRUtilities.weapons.new_ammo()
	
	golden_ammo.id = "Golden 12 Gauge"
	golden_ammo.bullet_node = load("res://mods-unpacked/TriggeredP-GoldenShotgun/Golden_Bullet.tscn")
	
	golden_ammo.ammo_mass = 640
	golden_ammo.recoil = 0.2
	golden_ammo.projectile_count = 6
	golden_ammo.price = 63.0
	
	PPRUtilities.weapons.add_ammo(golden_ammo)

func add_golden_shotgun():
	var golden_shotgun = PPRUtilities.weapons.new_weapon()
	
	golden_shotgun.id = "Golden Shotgun"
	golden_shotgun.description = "The shotgun is completely plated with 24-karat gold\n(upon closer inspection it is clear that it is not gold)\n\n[color=red][wave]Made by: TriggeredP[/wave][/color]"
	
	golden_shotgun.first_sale_day = 1
	golden_shotgun.price = 2500
	
	golden_shotgun.set_ammo_type("Golden 12 Gauge")
	golden_shotgun.magazine_size = 48
	golden_shotgun.fire_modes = [true, true, true]
	golden_shotgun.rof = 0.3
	
	golden_shotgun.small_arm = true
	
	golden_shotgun.mass = 10.0
	golden_shotgun.weapon_mass = 6 * 1000

	golden_shotgun.mesh = load("res://Models/Weapons/ks23.obj")
	golden_shotgun.barrel_mesh = null
	golden_shotgun.material = load("res://mods-unpacked/TriggeredP-GoldenShotgun/weapon_gold.tres")
	
	golden_shotgun.sfx = load("res://SFX/weapon_sfx/shotgun_2.wav")
	
	golden_shotgun.projectile_count = 6
	golden_shotgun.spread = 0.05

	PPRUtilities.weapons.add_weapon(golden_shotgun)
