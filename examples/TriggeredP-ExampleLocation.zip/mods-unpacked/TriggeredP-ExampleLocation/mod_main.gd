extends Node


const AUTHORNAME_MODNAME_DIR := "TriggeredP-ExampleLocation"
const AUTHORNAME_MODNAME_LOG_NAME := "TriggeredP-ExampleLocation:Main"

var mod_dir_path := ""
var extensions_dir_path := ""
var translations_dir_path := ""

func _init() -> void:
	mod_dir_path = ModLoaderMod.get_unpacked_dir().plus_file(AUTHORNAME_MODNAME_DIR)
	# Add extensions
	install_script_extensions()
	# Add translations
	add_translations()

func install_script_extensions() -> void:
	extensions_dir_path = mod_dir_path.plus_file("extensions")

func add_translations() -> void:
	translations_dir_path = mod_dir_path.plus_file("translations")

func _ready() -> void:
	var new_location = PPRUtilities.locations.new_location()
	
	new_location.id = "Example Location"
	new_location.description = "This is example of modded location for PPR"
	new_location.spawn_points = ["Center"]
	new_location.level = "res://mods-unpacked/TriggeredP-ExampleLocation/Location.tscn"
	
	PPRUtilities.locations.add_location(new_location)
