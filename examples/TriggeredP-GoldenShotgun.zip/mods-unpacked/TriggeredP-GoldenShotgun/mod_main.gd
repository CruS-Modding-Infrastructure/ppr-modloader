extends Node


const AUTHORNAME_MODNAME_DIR := "TriggeredP-GoldenShotgun"
const AUTHORNAME_MODNAME_LOG_NAME := "TriggeredP-GoldenShotgun:Main"

var mod_dir_path := ""
var extensions_dir_path := ""
var translations_dir_path := ""


func _init() -> void:
	mod_dir_path = ModLoaderMod.get_unpacked_dir().plus_file(AUTHORNAME_MODNAME_DIR)
	# Add extensions
	install_script_extensions()
	# Add translations
	add_translations()

func install_script_extensions() -> void:
	extensions_dir_path = mod_dir_path.plus_file("extensions")

func add_translations() -> void:
	translations_dir_path = mod_dir_path.plus_file("translations")

func _ready() -> void:
	var test_weapon = PPRUtilities.weapons.new_weapon()
	
	test_weapon.id = "Golden Shotgun"
	test_weapon.description = "The shotgun is completely plated with 24-karat gold\n(upon closer inspection it is clear that it is not gold)\n\n[color=red][wave]Made by: TriggeredP[/wave][/color]"
	
	test_weapon.first_sale_day = 1
	test_weapon.price = 2500
	
	test_weapon.set_ammo_type("12 Gauge")
	test_weapon.magazine_size = 48
	test_weapon.fire_modes = [true, true, true]
	test_weapon.rof = 0.3
	
	test_weapon.small_arm = true
	
	test_weapon.mass = 10.0
	test_weapon.weapon_mass = 6 * 1000

	test_weapon.mesh = load("res://Models/Weapons/ks23.obj")
	test_weapon.barrel_mesh = null
	test_weapon.material = load("res://mods-unpacked/TriggeredP-GoldenShotgun/weapon_gold.tres")
	
	test_weapon.sfx = load("res://SFX/weapon_sfx/shotgun_2.wav")
	
	test_weapon.projectile_count = 6
	test_weapon.spread = 0.05

	PPRUtilities.weapons.add_weapon(test_weapon)
